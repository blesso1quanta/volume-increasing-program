// Modifies the volume of an audio file

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include<math.h>
typedef uint8_t byte;
typedef int16_t twobytes;

// Number of bytes in .wav header
const int HEADER_SIZE = 44;

int main(int argc, char *argv[])
{
    // Check command-line arguments
    if (argc != 4)
    {
        printf("Usage: ./volume input.wav output.wav factor\n");
        return 1;
    }

    // Open files and determine scaling factor
    FILE *input = fopen(argv[1], "r");
    if (input == NULL)
    {
        printf("Could not open file.\n");
        return 1;
    }

    FILE *output = fopen(argv[2], "w");
    if (output == NULL)
    {
        printf("Could not open file.\n");
        return 1;
    }


    float factor = atof(argv[3]);
    byte storage[44];
   int a= fread(storage,sizeof(byte),44,input);
   int b= fwrite(storage,sizeof(byte),44,output);
    twobytes room=0;
    twobytes*king=&room;
    twobytes final=0;
    fseek(input,44,0);
    while(fread(king,sizeof(twobytes),1,input))
    {
        final=*king*factor;
        fwrite(&final,sizeof(twobytes),1,output);
    }


//try to prinf input and out files in hexadecimal format using read





     // TODO: Copy header from input file to output file

    // TODO: Read samples from input file and write updated data to output file

    // Close files

    fclose(input);
    fclose(output);
}
















